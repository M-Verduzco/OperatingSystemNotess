#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

// Define a structure for the message
struct msg_buffer {
    long msg_type;
    char msg_text[100];
};

int main() {
    // Generate a unique key for the message queue
    key_t key = ftok("/tmp", 'a');

    // Create a message queue
    int msgid = msgget(key, 0666 | IPC_CREAT);

    // Fork to create a child process
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }

    if (pid > 0) {
        // Parent process

        // Display parent process ID
        printf("Hello from Parent, PID: %d\n", getpid());

        // Prompt for a chore
        printf("Enter a chore for the child: ");
        char chore[100];
        fgets(chore, sizeof(chore), stdin);

        // Create a message structure
        struct msg_buffer message;
        message.msg_type = 1; // Message type must be greater than 0
        strcpy(message.msg_text, chore);

        // Send the message to the message queue
        msgsnd(msgid, &message, sizeof(message), 0);

        // Print confirmation
        printf("Chore sent to child. Waiting for reply...\n");

        // Wait for the child to reply
        struct msg_buffer reply;
        msgrcv(msgid, &reply, sizeof(reply), 2, 0);

        // Print the reply
        printf("Received reply from Child (PID: %d): %s\n", pid, reply.msg_text);
    } else {
        // Child process

        // Display child process ID
        printf("Hello from Child, PID: %d\n", getpid());

        // Wait for the parent to send a message
        struct msg_buffer message;
        msgrcv(msgid, &message, sizeof(message), 1, 0);

        // Print the received message
        printf("Received chore from Parent (PID: %d): %s\n", getppid(), message.msg_text);

        // Prompt for a reply
        printf("Enter a reply for the parent: ");
        char reply[100];
        fgets(reply, sizeof(reply), stdin);

        // Create a reply message structure
        struct msg_buffer reply_message;
        reply_message.msg_type = 2; // Message type must be greater than 0
        strcpy(reply_message.msg_text, reply);

        // Send the reply to the message queue
        msgsnd(msgid, &reply_message, sizeof(reply_message), 0);

        // Print confirmation
        printf("Reply sent to parent.\n");
    }

    // Remove the message queue
    msgctl(msgid, IPC_RMID, NULL);

    return 0;
}

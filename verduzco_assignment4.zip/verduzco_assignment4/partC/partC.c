#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    int n;

    // Input the value of n from the user
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Open a file for writing in CSV format
    FILE *file = fopen("process_info.csv", "w");

    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    // Write headers to the CSV file
    fprintf(file, "PID,PPID,Level,Process Name,Parent Process Name\n");

    fflush(file);

    // Loop to create n child processes
    for (int i = 0; i < n; ++i) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("Fork failed");
            return 1;
        } else if (pid == 0) {
            // Child process
            printf("Child process %d with PID %d\n", i + 1, getpid());
            fprintf(file, "%d,%d,%d,Child %d,Parent %d\n", getpid(), getppid(), i + 1, i + 1, getpid());
            fclose(file);
            exit(0);
        } else {
            // Parent process
            int status;
            waitpid(pid, &status, 0);  // Wait for the child to terminate
            printf("Parent process %d waiting for child %d\n", getpid(), pid);

            // You can add additional tasks for the parent process here

            break;  // Break from the loop after waiting for the first child
        }
    }

    // Common tasks for both parent and child processes
    printf("Process %d exiting\n", getpid());

    return 0;
}

